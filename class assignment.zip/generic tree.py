class Node(object):
    def __init__(self, data):
        self.data = data
        self.childern = []
        
    def add_childern(self, obj):
        self.childern.append(obj)
        
n = Node(5)    
p = Node(6)
q = Node(7)
r = Node(9)
m = Node(11)
s = Node(12)
l = Node(14)
t = Node(15)
n.add_childern(p)
n.add_childern(q)
n.add_childern(r)
p.add_childern(m)
p.add_childern(s)
q.add_childern(l)
r.add_childern(t)

for c in n.childern:
    print(c.data)

for c in p.childern:
    print(c.data)
    
for c in q.childern:
    print(c.data)
    
for c in r.childern:
    print(c.data)