class Tree(object):
    def __init__(self):
        self.left = None
        self.right = None
        self.data = None

# A function to do inorder tree traversal 
def printInorder(root): 
    if root: 
        printInorder(root.left) 
        print(root.data), 
        printInorder(root.right) 
  
# A function to do postorder tree traversal 
def printPostorder(root): 
    if root:
        printPostorder(root.left) 
        printPostorder(root.right) 
        print(root.data), 
  
  
# A function to do preorder tree traversal 
def printPreorder(root): 
    if root: 
        print(root.data),
        printPreorder(root.left) 
        printPreorder(root.right) 

root = Tree()
root.data = "A"     
root.left = Tree()
root.left.data = "B"
root.right = Tree()
root.right.data = "C"
root.left.left = Tree()
root.left.left.data = "D"
root.right.left = Tree()
root.right.left.data = "E"
root.right.right = Tree()
root.right.right.data = "G"
root.left.right = Tree()
root.left.right.data = "F"
root.left.right.left = Tree()
root.left.right.left.data = "M"
root.right.left.right = Tree()
root.right.left.right.data = "N"


print(root.right.left.right.data)
print(root.left.right.left.data)
print(root.right.left.data)
print(root.left.left.data)
print(root.right.left.right.data)
print(root.left.right.data)
print(root.right.right.data)
print(root.left.data)
print(root.right.data)
print(root.data)

print("to print preorder data")
printPreorder(root) 
print("to print inorder data")
printInorder(root) 
print("to print post order data")
printPostorder(root)
        




  
    